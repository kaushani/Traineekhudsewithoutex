package com.cg.trainee.controller;

import java.util.List;

import javax.validation.Valid;
import javax.xml.ws.BindingType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.bean.Trainee;
import com.cg.trainee.service.ItraineeService;

@Controller
public class TraineeController {

	@Autowired
	ItraineeService obService;
	@RequestMapping("/loginPage")
	public String showLoginPage()
	{
		return "loginPage";
	}
	@RequestMapping("/showInsertForm")
	/*public String InsertForm()
	{	
		return "insertForm";
	}*/
	public ModelAndView insertForm() 
	{
		
		// Create an attribute of type Question
		Trainee trainee=new Trainee();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("insertForm", "trainee", trainee);
	}
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(@ModelAttribute("trainee") @Valid Trainee trainee, BindingResult result )
	{
		ModelAndView mv= null;
		if(!result.hasErrors())
		{
			obService.addTrainee(trainee);
			/*mv= new ModelAndView("Success");
			mv.addObject("traineeId",trainee.getId());
		*/
			mv= new ModelAndView("Success", "traineeId", trainee.getId());
		}
		return mv;
		
	}
	@RequestMapping("/printAll")
	public ModelAndView printAll()
	{
		ModelAndView mv= null;
		List<Trainee> list=obService.printAll();
		mv=new ModelAndView("printAll","list",list);
		return mv;
	}
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam ("id") int id)
	{
		ModelAndView mv=null;
		String msg=obService.deleteTrainee(id);
		
		 mv= new ModelAndView("printAll","msg", msg);
		return mv;
	}
	@RequestMapping("/showSearchForm")
	public ModelAndView searchForm(@ModelAttribute("trainee") Trainee trainee)
	{
		
		Trainee t=new Trainee();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("searchForm", "trainee", t);

	}
	@RequestMapping("/search")
	public ModelAndView searchTrainee(@RequestParam ("id") int id)
	{
		ModelAndView mv= null;
		Trainee T=obService.searchTrainee(id);
		System.out.println("################"+ T);
		mv= new ModelAndView("searchForm", "trainee", T);
		return mv;
	}
	@RequestMapping("/showUpdateFormID")
	public ModelAndView updateTraineeForm(@ModelAttribute("trainee") Trainee trainee)
	{
		Trainee t=new Trainee();
		return new ModelAndView("updateForm","trainee", t);
		
	}
	@RequestMapping("/updateTraineeDetails")
	public ModelAndView updateTrainee(@RequestParam("traineeId") int traineeId)
	{
		Trainee trainee=obService.searchTrainee(traineeId);
		
			return new ModelAndView("updateForm", "trainee", trainee);
		
	}
	@RequestMapping("/updateTraineePersist")
	public ModelAndView updateTraineePersist(@ModelAttribute ("trainee") @Valid Trainee trainee, BindingResult result)
	{
		
		Trainee t=obService.updateTrainee(trainee);
		return new ModelAndView("Success", "traineeId", t.getId());
	}
}
