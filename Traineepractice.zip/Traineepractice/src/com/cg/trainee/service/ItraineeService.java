package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.bean.Trainee;

public interface ItraineeService {

	void addTrainee(Trainee trainee);
	List<Trainee> printAll();
	String deleteTrainee(int id);
	Trainee searchTrainee(int id);
	Trainee updateTrainee(Trainee trainee);
}
