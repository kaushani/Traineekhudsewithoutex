package com.cg.trainee.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.bean.Trainee;
import com.cg.trainee.dao.ITraineeDAO;
@Service
@Transactional
public class TraineeService implements ItraineeService{

	@Autowired
	ITraineeDAO dao;
	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		dao.addTrainee(trainee);
	}
	@Override
	public List<Trainee> printAll() {
		// TODO Auto-generated method stub
		return dao.printAll();
	}
	@Override
	public String deleteTrainee(int id) {
		// TODO Auto-generated method stub
		return dao.deleteTrainee(id);
	}
	@Override
	public Trainee searchTrainee(int id) {
		// TODO Auto-generated method stub
		System.out.println("Service ###################################"+dao.searchTrainee(id));

		return dao.searchTrainee(id);
		
	}
	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return dao.updateTrainee(trainee);
	}

}
