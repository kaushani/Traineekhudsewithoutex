package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.Trainee;

@Repository
public class TraineeDAOImpl implements ITraineeDAO{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		entityManager.flush();
	}

	@Override
	public List<Trainee> printAll() {
		// TODO Auto-generated method stub
		TypedQuery<Trainee> query = entityManager.createQuery("SELECT trainee FROM Trainee trainee", Trainee.class);
		return query.getResultList();
	}

	@Override
	public String deleteTrainee(int id) {
		// TODO Auto-generated method stub
		Trainee trainee=entityManager.find(Trainee.class, id);
		entityManager.remove(trainee);
		System.out.println("Deleted successfully!");
		String str="Record "+id +"is deleted";
		return str;
	}

	@Override
	public Trainee searchTrainee(int id) {
		// TODO Auto-generated method stub
		Trainee trainee=entityManager.find(Trainee.class, id);
		System.out.println("###################################"+trainee);
		return trainee;
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		System.out.println("in updateeeeee");
		Trainee localTrainee=entityManager.find(Trainee.class, trainee.getId());
		System.out.println("FOUNDDDDDDDDDDDDDDDDDDDD"+localTrainee);
		localTrainee.setName(trainee.getName());
		localTrainee.setLocation(trainee.getLocation());
		localTrainee.setDomain(trainee.getDomain());
		//entityManager.merge(localTrainee);
		System.out.println("Mergeddddddddddddddddddddddddd");
		return localTrainee;
	}
	
}
