package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.bean.Trainee;


public interface ITraineeDAO {

	void addTrainee(Trainee trainee);
	List<Trainee> printAll();
	String deleteTrainee(int id);
	Trainee searchTrainee(int id);
	Trainee updateTrainee(Trainee trainee);
}
